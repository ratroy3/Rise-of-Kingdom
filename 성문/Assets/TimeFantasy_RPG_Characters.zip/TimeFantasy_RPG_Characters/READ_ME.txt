Hey thanks for buying my graphics pack!

This pack is compatible with all graphics in my Time Fantasy style.


Here is what you got:

32 main "hero/villain" characters
-4-directional walking animations
-Emotion animations: nod, smh, laugh, surprise
-Special animation: 3-frame weapon or action pose

24 military characters
-4-directional walking animations
-Medievial solders/knights , modern/future troopers and generals
-Special animation: 3-frame weapon "ready" pose

16 NPCs
-4-directional walking animations
-Recolored NPCs make 32 NPCs

Also Includes
-a "naked" template sprite for artists
-8 animated treasure chests
-8 bonus characters from timefantasy.net*
-animal sprites (4 cats, 4 dogs) from timefantasy.net*

*these sprites were previously released for free on the timefantasy blog. 
they're included for convenience


-------------------------
Time Fantasy Website
 timefantasy.net

Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues