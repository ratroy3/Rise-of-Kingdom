Hey thanks for buying my graphics pack!

This pack is compatible with all graphics in my Time Fantasy style.

These tiles are arranged in sheets with a 16x16 grid. I tried to organize them in a convenient way for you.

The pack includes a visual guide (guide.png) that explains tips and tricks on the best way to use the tiles. 
I'd recommend checking that out before using these.


Here is what you got:

Hundreds of tiles!

- Grass, dirt, rock, and sand terrain with loads of variations
- Outside tiles for forests, mountains, cliffs and deserts
- Animated water tiles
- Houses, shops and castles - inside and outside!
- A variety of dungeons: caves, mines, ruins and temples
- World map tiles

Also Includes
- Animated doors that open and close
- Animated traps and switches for puzzles
- kitchen tiles from timefantasy.net* 

*these tiles were previously released for free on the timefantasy blog. they're included for convenience


-------------------------
Time Fantasy Website
 timefantasy.net

Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues